namespace TSIB_JQuery.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class itwiwan_kaohisung
    {
        [Key]
        public long Seq { get; set; }

        [StringLength(255)]
        public string name { get; set; }

        [StringLength(255)]
        public string address { get; set; }

        public double? Lng { get; set; }

        public double? Lat { get; set; }
    }
}
