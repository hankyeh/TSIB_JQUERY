﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using TSIB_JQuery.Models;

namespace TSIB_JQuery.Controllers
{
    public class ToiletController : ApiController
    {
        private Model1 db = new Model1();

        // GET: api/Toilet
        public IQueryable GetPublic_Toilet()
        {
            IQueryable result = (from x in db.Public_Toilet
                                select x).Take(5);
            return result;
        }

        // GET: api/Toilet/5
        public IQueryable GetPublic_Toilet( int top) {
            IQueryable result = (from x in db.Public_Toilet
                                 select x).Take(top);
            return result;
        }
        //[ResponseType(typeof(Public_Toilet))]
        //public IHttpActionResult GetPublic_Toilet(long id)
        //{
        //    Public_Toilet public_Toilet = db.Public_Toilet.Find(id);
        //    if (public_Toilet == null)
        //    {
        //        return NotFound();
        //    }

        //    return Ok(public_Toilet);
        //}
        // POST: api/Toilet/
        public IQueryable PostPublic_Toilet(int top) {
            IQueryable result = (from x in db.Public_Toilet
                                 select x).Take(top);
            return result;
        }

        // PUT: api/Toilet/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutPublic_Toilet(long id, Public_Toilet public_Toilet)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != public_Toilet.Seq)
            {
                return BadRequest();
            }

            db.Entry(public_Toilet).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Public_ToiletExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Toilet
        [ResponseType(typeof(Public_Toilet))]
        public IQueryable PostPublic_Toilet(Public_Toilet public_Toilet)
        {
            //if (!ModelState.IsValid)
            //{
            //    return BadRequest(ModelState);
            //}

            //db.Public_Toilet.Add(public_Toilet);
            //db.SaveChanges();

            IQueryable result = (from x in db.Public_Toilet
                                 select x).Take( (int) public_Toilet.Seq );

            return result;
        }

        // DELETE: api/Toilet/5
        [ResponseType(typeof(Public_Toilet))]
        public IHttpActionResult DeletePublic_Toilet(long id)
        {
            Public_Toilet public_Toilet = db.Public_Toilet.Find(id);
            if (public_Toilet == null)
            {
                return NotFound();
            }

            db.Public_Toilet.Remove(public_Toilet);
            db.SaveChanges();

            return Ok(public_Toilet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool Public_ToiletExists(long id)
        {
            return db.Public_Toilet.Count(e => e.Seq == id) > 0;
        }
    }
}