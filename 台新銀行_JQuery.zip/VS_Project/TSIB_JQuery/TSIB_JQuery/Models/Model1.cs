namespace TSIB_JQuery.Models {
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Model1 : DbContext {
        public Model1()
            : base("name=Model1") {
        }

        public virtual DbSet<Public_Toilet> Public_Toilet { get; set; }
        public virtual DbSet<catm_location> catm_location { get; set; }
        public virtual DbSet<cbike> cbike { get; set; }
        public virtual DbSet<itwiwan_kaohisung> itwiwan_kaohisung { get; set; }
        public virtual DbSet<water_cooler> water_cooler { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder) {
        }
    }
}
