﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TSIB_JQuery.Models;

namespace TSIB_JQuery.Controllers
{
    public class ToiletTabController : Controller
    {
        private Model1 db = new Model1();

        public ActionResult ShowTab() {
            return View(db.Public_Toilet.Take(300).ToList());
        }

        public ActionResult ShowTabAjax() {
            return View();
        }

        // GET: ToiletTab
        public ActionResult Index()
        {
            return View(db.Public_Toilet.ToList());
        }

        // GET: ToiletTab/Details/5
        public ActionResult Details(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Public_Toilet public_Toilet = db.Public_Toilet.Find(id);
            if (public_Toilet == null)
            {
                return HttpNotFound();
            }
            return View(public_Toilet);
        }

        // GET: ToiletTab/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ToiletTab/Create
        // 若要免於過量張貼攻擊，請啟用想要繫結的特定屬性，如需
        // 詳細資訊，請參閱 https://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Seq,name,address,Lng,Lat")] Public_Toilet public_Toilet)
        {
            if (ModelState.IsValid)
            {
                db.Public_Toilet.Add(public_Toilet);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(public_Toilet);
        }

        // GET: ToiletTab/Edit/5
        public ActionResult Edit(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Public_Toilet public_Toilet = db.Public_Toilet.Find(id);
            if (public_Toilet == null)
            {
                return HttpNotFound();
            }
            return View(public_Toilet);
        }

        // POST: ToiletTab/Edit/5
        // 若要免於過量張貼攻擊，請啟用想要繫結的特定屬性，如需
        // 詳細資訊，請參閱 https://go.microsoft.com/fwlink/?LinkId=317598。
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Seq,name,address,Lng,Lat")] Public_Toilet public_Toilet)
        {
            if (ModelState.IsValid)
            {
                db.Entry(public_Toilet).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(public_Toilet);
        }

        // GET: ToiletTab/Delete/5
        public ActionResult Delete(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Public_Toilet public_Toilet = db.Public_Toilet.Find(id);
            if (public_Toilet == null)
            {
                return HttpNotFound();
            }
            return View(public_Toilet);
        }

        // POST: ToiletTab/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(long id)
        {
            Public_Toilet public_Toilet = db.Public_Toilet.Find(id);
            db.Public_Toilet.Remove(public_Toilet);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
